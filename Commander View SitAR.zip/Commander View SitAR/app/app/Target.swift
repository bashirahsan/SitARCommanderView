//
//  Target.swift
//  app
//
//  Created by Ahsan on 18/05/2020.
//  Copyright © 2020 Faraz saeed. All rights reserved.
//

import Foundation
import CoreLocation

struct Target{
    var latitude: CLLocationDegrees
    var longitude: CLLocationDegrees
    var heading: Double
    var altitude: Float
}
