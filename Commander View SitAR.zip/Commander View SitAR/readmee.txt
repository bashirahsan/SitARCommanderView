1. download pod file of mapbox ios sdk
2. use your mapbox key generated from mapbox account
